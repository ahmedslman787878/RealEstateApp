package com.example.realestate.databinding

import android.view.View
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip

class ActivityAddPropertyBinding private constructor() {
    lateinit var root: View
    lateinit var btnCategoryProperties: MaterialButton
    lateinit var btnCategoryFactories: MaterialButton
    lateinit var btnCategoryEquipment: MaterialButton
    lateinit var chipApartment: Chip
    lateinit var chipVilla: Chip
    lateinit var chipLand: Chip
    lateinit var chipShop: Chip
    lateinit var chipSale: Chip
    lateinit var chipRent: Chip
    lateinit var btnAddImages: View
    
    companion object {
        fun inflate(inflater: android.view.LayoutInflater): ActivityAddPropertyBinding {
            return ActivityAddPropertyBinding()
        }
    }
}
