package com.example.realestate.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.realestate.R
import com.example.realestate.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityProfileBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.my_account)
        
        setupProfile()
        setupMenuItems()
    }
    
    private fun setupProfile() {
        binding.apply {
            tvUserName.text = getString(R.string.test_user)
            tvUserEmail.text = getString(R.string.test_email)
            tvTemporaryNote.text = getString(R.string.temporary_account)
        }
    }
    
    private fun setupMenuItems() {
        binding.apply {
            cardPersonalInfo.setOnClickListener {
                // Navigate to personal info
            }
            
            cardMyAds.setOnClickListener {
                // Navigate to my ads
            }
            
            cardMessages.setOnClickListener {
                // Navigate to messages
            }
            
            cardSettings.setOnClickListener {
                // Navigate to settings
            }
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
