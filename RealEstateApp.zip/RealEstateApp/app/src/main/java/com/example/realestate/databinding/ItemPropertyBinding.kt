package com.example.realestate.databinding

import android.view.View
import android.widget.TextView

class ItemPropertyBinding private constructor() {
    lateinit var root: View
    lateinit var tvTitle: TextView
    lateinit var tvDescription: TextView
    lateinit var tvLocation: TextView
    lateinit var tvPrice: TextView
    lateinit var tvType: TextView
    
    companion object {
        fun inflate(inflater: android.view.LayoutInflater, parent: android.view.ViewGroup, attachToParent: Boolean): ItemPropertyBinding {
            return ItemPropertyBinding()
        }
    }
}
