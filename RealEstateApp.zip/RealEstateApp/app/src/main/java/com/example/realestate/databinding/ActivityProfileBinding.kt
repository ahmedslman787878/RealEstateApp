package com.example.realestate.databinding

import android.view.View
import android.widget.TextView
import androidx.cardview.widget.CardView

class ActivityProfileBinding private constructor() {
    lateinit var root: View
    lateinit var tvUserName: TextView
    lateinit var tvUserEmail: TextView
    lateinit var tvTemporaryNote: TextView
    lateinit var cardPersonalInfo: CardView
    lateinit var cardMyAds: CardView
    lateinit var cardMessages: CardView
    lateinit var cardSettings: CardView
    
    companion object {
        fun inflate(inflater: android.view.LayoutInflater): ActivityProfileBinding {
            return ActivityProfileBinding()
        }
    }
}
