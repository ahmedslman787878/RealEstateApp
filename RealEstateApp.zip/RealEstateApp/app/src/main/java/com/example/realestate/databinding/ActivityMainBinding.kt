package com.example.realestate.databinding

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip

// This is a stub class for ViewBinding
// Android Studio will generate the actual binding classes during build
class ActivityMainBinding private constructor() {
    lateinit var root: View
    lateinit var recyclerViewProperties: RecyclerView
    lateinit var bottomNavigation: BottomNavigationView
    lateinit var chipApartment: Chip
    lateinit var chipVilla: Chip
    lateinit var chipLand: Chip
    lateinit var chipShop: Chip
    
    companion object {
        fun inflate(inflater: android.view.LayoutInflater): ActivityMainBinding {
            return ActivityMainBinding()
        }
    }
}
