package com.example.realestate.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Property(
    val id: String,
    val title: String,
    val description: String,
    val type: PropertyType,
    val category: PropertyCategory,
    val adType: AdType,
    val location: String,
    val price: Double,
    val imageUrl: String,
    val isFavorite: Boolean = false
) : Parcelable

enum class PropertyType {
    APARTMENT,
    VILLA,
    LAND,
    SHOP
}

enum class PropertyCategory {
    PROPERTIES,
    FACTORIES,
    EQUIPMENT
}

enum class AdType {
    SALE,
    RENT
}
