package com.example.realestate.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.realestate.R
import com.example.realestate.adapters.PropertyAdapter
import com.example.realestate.databinding.ActivityMainBinding
import com.example.realestate.models.AdType
import com.example.realestate.models.Property
import com.example.realestate.models.PropertyCategory
import com.example.realestate.models.PropertyType
import com.google.android.material.chip.Chip

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var propertyAdapter: PropertyAdapter
    private var allProperties = mutableListOf<Property>()
    private var selectedFilter: PropertyType? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupRecyclerView()
        setupFilterChips()
        setupBottomNavigation()
        loadSampleData()
    }
    
    private fun setupRecyclerView() {
        propertyAdapter = PropertyAdapter { property ->
            // Handle property click
        }
        
        binding.recyclerViewProperties.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = propertyAdapter
        }
    }
    
    private fun setupFilterChips() {
        binding.chipApartment.setOnClickListener { filterProperties(PropertyType.APARTMENT) }
        binding.chipVilla.setOnClickListener { filterProperties(PropertyType.VILLA) }
        binding.chipLand.setOnClickListener { filterProperties(PropertyType.LAND) }
        binding.chipShop.setOnClickListener { filterProperties(PropertyType.SHOP) }
    }
    
    private fun filterProperties(type: PropertyType) {
        selectedFilter = if (selectedFilter == type) null else type
        
        val filtered = if (selectedFilter == null) {
            allProperties
        } else {
            allProperties.filter { it.type == selectedFilter }
        }
        
        propertyAdapter.submitList(filtered)
        updateChipStates()
    }
    
    private fun updateChipStates() {
        binding.chipApartment.isChecked = selectedFilter == PropertyType.APARTMENT
        binding.chipVilla.isChecked = selectedFilter == PropertyType.VILLA
        binding.chipLand.isChecked = selectedFilter == PropertyType.LAND
        binding.chipShop.isChecked = selectedFilter == PropertyType.SHOP
    }
    
    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    true
                }
                R.id.nav_favorites -> {
                    // Navigate to favorites
                    true
                }
                R.id.nav_add -> {
                    startActivity(Intent(this, AddPropertyActivity::class.java))
                    true
                }
                R.id.nav_account -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }
    
    private fun loadSampleData() {
        allProperties.addAll(
            listOf(
                Property(
                    id = "1",
                    title = "شقة فاخرة في حي الياسمين",
                    description = "شقة مفروشة بالكامل مع إطلالة رائعة",
                    type = PropertyType.APARTMENT,
                    category = PropertyCategory.PROPERTIES,
                    adType = AdType.SALE,
                    location = "حي الياسمين، الرياض",
                    price = 450000.0,
                    imageUrl = ""
                ),
                Property(
                    id = "2",
                    title = "فيلا حديثة للإيجار",
                    description = "فيلا 5 غرف مع حديقة واسعة",
                    type = PropertyType.VILLA,
                    category = PropertyCategory.PROPERTIES,
                    adType = AdType.RENT,
                    location = "حي النرجس، الرياض",
                    price = 8000.0,
                    imageUrl = ""
                ),
                Property(
                    id = "3",
                    title = "أرض تجارية للبيع",
                    description = "أرض على شارع تجاري رئيسي",
                    type = PropertyType.LAND,
                    category = PropertyCategory.PROPERTIES,
                    adType = AdType.SALE,
                    location = "طريق الملك فهد، جدة",
                    price = 1200000.0,
                    imageUrl = ""
                )
            )
        )
        
        propertyAdapter.submitList(allProperties)
    }
}
