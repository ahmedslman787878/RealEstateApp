package com.example.realestate.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.realestate.databinding.ItemPropertyBinding
import com.example.realestate.models.Property

class PropertyAdapter(
    private val onPropertyClick: (Property) -> Unit
) : ListAdapter<Property, PropertyAdapter.PropertyViewHolder>(PropertyDiffCallback()) {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PropertyViewHolder {
        val binding = ItemPropertyBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return PropertyViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: PropertyViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
    
    inner class PropertyViewHolder(
        private val binding: ItemPropertyBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        
        fun bind(property: Property) {
            binding.apply {
                tvTitle.text = property.title
                tvDescription.text = property.description
                tvLocation.text = property.location
                tvPrice.text = "${property.price} ريال"
                
                val typeText = when (property.type) {
                    com.example.realestate.models.PropertyType.APARTMENT -> "شقة"
                    com.example.realestate.models.PropertyType.VILLA -> "فيلا"
                    com.example.realestate.models.PropertyType.LAND -> "أرض"
                    com.example.realestate.models.PropertyType.SHOP -> "محل"
                }
                tvType.text = typeText
                
                root.setOnClickListener {
                    onPropertyClick(property)
                }
            }
        }
    }
    
    private class PropertyDiffCallback : DiffUtil.ItemCallback<Property>() {
        override fun areItemsTheSame(oldItem: Property, newItem: Property): Boolean {
            return oldItem.id == newItem.id
        }
        
        override fun areContentsTheSame(oldItem: Property, newItem: Property): Boolean {
            return oldItem == newItem
        }
    }
}
