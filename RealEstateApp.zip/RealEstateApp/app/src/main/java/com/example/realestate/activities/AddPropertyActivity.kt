package com.example.realestate.activities

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.realestate.R
import com.example.realestate.databinding.ActivityAddPropertyBinding
import com.google.android.material.snackbar.Snackbar

class AddPropertyActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityAddPropertyBinding
    private val selectedImages = mutableListOf<Uri>()
    private val IMAGE_PICKER_REQUEST = 100
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddPropertyBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.add_property)
        
        setupCategorySelection()
        setupPropertyTypeSelection()
        setupAdTypeSelection()
        setupImagePicker()
    }
    
    private fun setupCategorySelection() {
        binding.apply {
            btnCategoryProperties.setOnClickListener {
                selectCategory(btnCategoryProperties, "properties")
            }
            btnCategoryFactories.setOnClickListener {
                selectCategory(btnCategoryFactories, "factories")
            }
            btnCategoryEquipment.setOnClickListener {
                selectCategory(btnCategoryEquipment, "equipment")
            }
        }
    }
    
    private fun selectCategory(selectedButton: com.google.android.material.button.MaterialButton, category: String) {
        binding.apply {
            btnCategoryProperties.isSelected = false
            btnCategoryFactories.isSelected = false
            btnCategoryEquipment.isSelected = false
            
            selectedButton.isSelected = true
        }
    }
    
    private fun setupPropertyTypeSelection() {
        binding.apply {
            chipApartment.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) clearOtherPropertyTypes(chipApartment.id)
            }
            chipVilla.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) clearOtherPropertyTypes(chipVilla.id)
            }
            chipLand.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) clearOtherPropertyTypes(chipLand.id)
            }
            chipShop.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) clearOtherPropertyTypes(chipShop.id)
            }
        }
    }
    
    private fun clearOtherPropertyTypes(selectedId: Int) {
        binding.apply {
            if (selectedId != chipApartment.id) chipApartment.isChecked = false
            if (selectedId != chipVilla.id) chipVilla.isChecked = false
            if (selectedId != chipLand.id) chipLand.isChecked = false
            if (selectedId != chipShop.id) chipShop.isChecked = false
        }
    }
    
    private fun setupAdTypeSelection() {
        binding.apply {
            chipSale.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) chipRent.isChecked = false
            }
            chipRent.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) chipSale.isChecked = false
            }
        }
    }
    
    private fun setupImagePicker() {
        binding.btnAddImages.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            intent.type = "image/*"
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            startActivityForResult(intent, IMAGE_PICKER_REQUEST)
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == IMAGE_PICKER_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.let {
                if (it.clipData != null) {
                    val count = it.clipData!!.itemCount
                    for (i in 0 until count) {
                        selectedImages.add(it.clipData!!.getItemAt(i).uri)
                    }
                } else if (it.data != null) {
                    selectedImages.add(it.data!!)
                }
                
                Snackbar.make(
                    binding.root,
                    "تم إضافة ${selectedImages.size} صورة",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
